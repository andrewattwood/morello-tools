#ifndef _SYS_CHERI_H
#define _SYS_CHERI_H

#define CHERI_PERM_SW_VMEM    (1 << 2) /* User[0] permission */

#endif // _SYS_CHERI_H
