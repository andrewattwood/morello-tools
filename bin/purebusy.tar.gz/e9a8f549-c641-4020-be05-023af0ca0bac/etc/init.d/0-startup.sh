#!/bin/busybox sh

# SPDX-License-Identifier: BSD-3-Clause

printf "Startup...\n"
